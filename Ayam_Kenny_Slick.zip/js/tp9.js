function ajout_ajax(debut,fin){ 
    $.ajax({
        url: "post.php", // Quel script PHP va traîter ?
        data: { // Les éléments pour répondre
            de:debut,
            a:fin
        },
    
        type:"GET", // La façon de les récupérer en PHP
        dataType :"json", // Le type de réponse attendu
    }) //Sans ";"

    .done(function(json){ 
        console.log("json");
        for(var i=0;i<json.length;i++){
            $("section").append("<img src='img/st"+json[i]+".jpg'/>");
        }
    })
    .fail(function(xhr,status,errorThrown){
        console.log("Nous sommes désolé mais ça ne fonctionne pas !" );
        console.log("Error:"+errorThrown);
        console.log("Status:"+status);
        console.dir(xhr);
    })
    .always(function(xhr,status){
        console.log("La requête est terminée !");
    });
}

function random_ajax(debut,fin){
    $.ajax({
        url: "post_random.php", //Quel script PHP va traîter ?
        data: { //Les éléments pour répondre
            a:debut,
            b:fin
        },
    
        type:"GET", // La façon de les récupérer en PHP
        dataType :"json", // Le type de réponse attendu
    }) //Sans ";"

    .done(function(json){ 
        console.log("json");
        for(var i=0;i<json.length;i++){
            $("section").append("<img src='img/st"+json[i]+".jpg'/>");
        }
    })
    .fail(function(xhr,status,errorThrown){
        console.log("Nous sommes désolé mais ça ne fonctionne pas !" );
        console.log("Error:"+errorThrown);
        console.log("Status:"+status);
        console.dir(xhr);
    })
    .always(function(xhr,status){
        console.log("La requête est terminée !");
    });
}