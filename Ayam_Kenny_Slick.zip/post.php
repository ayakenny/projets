<?php
    //Et du côté de post.php ?
    $liste=range($_REQUEST['de'],$_REQUEST['a']);
    echo json_encode($liste);
?>