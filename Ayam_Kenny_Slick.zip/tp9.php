<!DOCTYPE html>
<html>
<head>
	<title>TP 9</title>
	<meta charset="utf-8">
	<script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/tp9.js"></script>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <h1>Test de Ajax</h1>
    <section>
        <p>
          Quam ob rem vita quidem talis fuit vel fortuna vel gloria, ut nihil posset accedere, moriendi autem sensum celeritas abstulit; quo de genere mortis difficile dictu est; quid homines suspicentur, videtis; hoc vere tamen licet dicere, P.
        </p>
        
        <button onclick="ajout_ajax(1,3);">1 a 3 </button>
        <button onclick="ajout_ajax(4,5);">4 a 5</button> 
        <button onclick="ajout_ajax(5,7);">5 a 7</button>
        <button onclick="var random=Math.floor(Math.random()*(8-1))+1; ajout_ajax(random,random)">Tirer une image au hasard</button>
        <button onclick="random_ajax(1,7);">Afficher toutes les images au hasard</button>
    </section>
</body>
</html>