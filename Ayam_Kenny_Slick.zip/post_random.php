<?php
    $random=range($_REQUEST['a'],$_REQUEST['b']);
    shuffle($random);
    echo json_encode($random);
?>