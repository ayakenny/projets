-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 18 mai 2021 à 22:42
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `monsite`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id_article` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(100) NOT NULL,
  `contenu` text NOT NULL,
  `slug` varchar(40) NOT NULL,
  PRIMARY KEY (`id_article`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id_article`, `titre`, `contenu`, `slug`) VALUES
(1, 'Les statistiques sur les plus gros mensonges des programmeurs viennent de tomber', '1) Le site devrait fonctionner maintenant.<br/>\r\n2) ça ne prendra qu\'un instant.<br/>\r\n3) Je le ferai plus tard.<br/>\r\n4) C\'est un bug facile à corriger.<br/>', 'dev_web_et_mensonges'),
(2, 'Jeanne d\'arc a la fibre', 'Et oui, elle a Free !', 'jeanne_d_arc'),
(3, 'Quel IDE choisir ?', 'Visual Studio Code ? Non aucun challenge.<br/>\r\nAtom ? Encore trop simple !<br/>\r\nWord ? Voilà, ça c\'est un défi.<br/>', 'quel_ide'),
(4, 'L\'histoire de la patate douce qui n\'était pas douce', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'patate_douce'),
(5, 'Nom d\'un Kiwi', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'un_kiwi'),
(6, 'Découvrez les secrets du chocolat au lait sans lait', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'chocolat_au_lait_sans_lait'),
(7, 'La banane et ses bienfaits qui vous donnent la banane', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'banane_bienfaits'),
(8, 'Une ducati achetée, une boite à outils offerte !', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'ducati_boite_a_outils');

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `idimage` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `alt` varchar(45) NOT NULL,
  `source` varchar(255) NOT NULL,
  PRIMARY KEY (`idimage`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`idimage`, `title`, `alt`, `source`) VALUES
(1, 'Paysage', 'paysage_montagne', '/media/image/image_1.jpg'),
(2, 'Une magnifique moto', 'moto_custom', '/media/image/image_2.jpg'),
(3, 'Un moteur de moto', 'moteur_de_moto', '/media/image/image_3.jpg'),
(4, 'Une photo de nuit', 'photo_de_nuit', '/media/image/image_4.jpg'),
(5, 'Work Hard', 'image_du_texte', '/media/image/image_5.jpg'),
(6, 'Une route de nuit', 'route_de_nuit', '/media/image/image_6.jpg'),
(7, 'Lumières dans le noir', 'lumiere_dans_le_noir', '/media/image/image_7.jpg'),
(8, 'Une moto de face', 'joli_moto', '/media/image/image_8.jpg'),
(9, 'Une moto de dos', 'magnifique_moto', '/media/image/image_9.jpg'),
(10, 'Un vélo en action', 'velo_en_action', '/media/image/image_10.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `idusers` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`idusers`, `login`, `password`) VALUES
(40, 'toto', '$2y$10$8Oe3zPb51DofGl1GF8zex.mu4tH4vQhAhcaP//QTTAoK5NcSSHDsK'),
(39, 'titi', '$2y$10$uQFzeoMHMpI2FuNhqbp1cOWxuUZo/F3u6GIKhBdn90V/jUh6izdTm'),
(38, 'toto', '$2y$10$SkaBZGstQbQBBPsC/3n3AucoPGiCVXK/WiZDswOr6uRwmRuBGvi1m'),
(37, 'titi', '$2y$10$pr43M0JloFl7utzFKWHtX.x5J.RpBV6tRvrzHGHyBBspS8EpOBbYi'),
(36, 'toto', '$2y$10$.Sqyc2H.RqaNxKRVKB9C7.PVnK3ZmrN03Ybji5fm8o7bQfDkeRicq'),
(35, 'titi', '$2y$10$immm/TKGCk8N9RDydYltD.lBM5q59CU0z.cWL37OE0UobiPaSf8D2'),
(34, 'toto', '$2y$10$sAQciHm6iNSl2Tw7BAgj0ObB4GpoyofD5cDrOv91z7QjYQaj5VWWq'),
(33, 'titi', '$2y$10$qWZBxsPKSnaO9anggPMGB.uJHLouTusIZUGbvtt85/nNTrT0DyvbO'),
(32, 'toto', '$2y$10$TK66YWvx6HOvcGrqJHP2YelWUYkfPhlU0RLAbueBRwNT7q9QAe5L6'),
(31, 'titi', '$2y$10$6V10QMCVunpPLTu51t4wveYrb3B37EadabEsONwFwSLuHdwxbD.im'),
(30, 'toto', '$2y$10$D1lYsvK/f5197rBpV4.LNOj1aWkrnB9qoYuZGRkOED8djUgXtuKVK'),
(29, 'titi', '$2y$10$XF3FwmqiI1rAgJtHPznIqOuqTS2Ti0OJb1edrSLxslwsNZkTgJ8aC'),
(28, 'toto', '$2y$10$n/VL.sct5yJOpERswHrWxeRbgbrtVQrmz4JiHyv.eJq8wvayPYDH.'),
(27, 'titi', '$2y$10$tfbWKwk9w2sIwsn9m8.7gOZchW3ugqjV3GvKS1yVhP1IwHY9kBa6y'),
(26, 'toto', '$2y$10$6WBjcypX2TQruuGq1RkymeHA2gNAHBpL9vEwtkKgVeAGgfd1VWNUW'),
(25, 'titi', '$2y$10$d.Um/kbrawMxjE///c6FJ.xObJZGmah5/nS49J2WEqyN.yvGh.40K'),
(24, 'toto', '$2y$10$dJUBq0BYIb1NGfn8CeEqNuHebnI/ktp7pNSWk5H7mv.qoXAJdQ1dq'),
(23, 'titi', '$2y$10$2F/HmjVAHIrc9q3wyAyyHeNUJ3VEkj6r.wxSEFujUUG.gh8Hu.xVq'),
(22, 'toto', '$2y$10$t0wjz0ISHnYKSuzUgmLjOO8E6sXuixTL2akUbHhwmWjmku1aELCKW'),
(20, 'toto', '$2y$10$FpN9oPYo07oLzFK81XIwl.ndqdTAu2Bs0DH7ZM.Ldz5ji.JBNTpdq'),
(21, 'titi', '$2y$10$813f3iP7eOAYKa2k4Dqo/eeWg32rYW084/TgqmmEwzso5KpwxiKJa'),
(41, 'titi', '$2y$10$P758rsxwruKo6iyTj3Ebmuf1MEn.2inlx9mFXYqXub4Auiw4BSBJy');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
