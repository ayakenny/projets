<?php
abstract class Model{
	//Info de la BDD
	private $host = "localhost";
	private $db_name = "monsite"; 
	private $username = "root";
	private $password = "";

	//propriété qui contiendra l'instance de connexion
	protected $_connexion;

	//propriéyés pour personnaliser les requêtes
	public $table;
	public $id;

	/**
	* fonction d'initialisation de la BDD
	*
	* @return void
	*/

	public function getConnection(){
		//suprime la connexion précédente
		$this->_connexion = null;

		mysqli_report(MYSQLI_REPORT_STRICT);
		//essaie pour se connecter à la base
		try{
			$this->_connexion = new mysqli($this->host, $this->username, $this->password, $this->db_name);
			$this->_connexion->set_charset("utf8");
		}catch(mysqli_sql_exception $exception){
			echo "Erreur de connexion : ".$exception->errorMessage();
			/*echo "Fichier : ".$exception->getFile()."<br/>\n";
    		echo "Ligne : ".$exception->getLine()."<br/>\n";
   			echo "Code : ".$exception->getCode()."<br/>\n";
    		echo "Trace affichable : ".$exception->getTraceAsString();*/
		}
		catch(Throwable $t){ // Il s’agit d’une erreur non gérée par throw
			echo "<p>Erreur imprévue : ".$t->getMessage()."</p>\n";
		}
	}

	/**
	* méthode permettant d'obtenir un enregistrement de la table choisir en fonction d'un id
	*
	* @return void
	*/

	public function getOne(){
		$sql = "SELECT * FROM ".$this->table." WHERE id=".$this->id;
		$query = $this->_connexion->query($sql);
		return $query->fetch_assoc();
	}

	/**
	* méthode permettant d'obtenir tous les enregistrements de la tanle choisie
	*
	* @return void
	*/

	public function getAll(){
		$sql = "SELECT * FROM ".$this->table; 
		$query = $this->_connexion->query($sql); 
		return $query->fetch_all(MYSQLI_ASSOC);
	}
}
?>