<?php
	require_once "erreur.php";
    session_start();

    $connexion = new mysqli('localhost','root','','thesite');

    if(isset($_SESSION['session_co'])){
        if(isset($_POST['deco'])) { //action déconnecter
            unset($_SESSION['session_co']);
            //echo "Get out of here";
            //require ("form_login.php");
            header('Location: /main');
            exit(0);
        }else{
            require "form_deco.php";
        }
    }else{
        if(isset($_POST["co"])){

	        if($connexion->connect_errno){
	            echo "Erreur de connexion n°{$connexion->connect_errno} : {$connexion->connect_error}";
	        }else{
	            $login = $_POST['login'];
		        $sql = "SELECT `password` FROM `bouser` WHERE `login` = ?";
		        $stmt = $connexion->prepare($sql);
		        erreur($connexion);
		        $stmt->bind_param("s", $login);
		        $stmt->execute();
		        erreur($connexion);

		        $stmt->bind_result($col_password); //Si tout à bien fonctionné, on pourra récupérer dans la variable $hash le MDP hashé.
		        if($stmt->fetch()){ //Si le MDP est hashé 
		            if(password_verify($_POST['mdp'], $col_password)){ //Dans ce if on crée une session. 
		                $_SESSION["session_co"]=$_POST["login"];
		                require"form_deco.php";
		            }else{
		            	echo "Erreur dans la saisie";
		                require"form_login.php";
		                exit(0);
		            }
		        }else{
		            require"form_login.php";
		            exit(0);
		        } 

		        $stmt->close();
		        $connexion->close();
		    }
	    }else{
	        require "form_login.php";
	        exit(0);
        }
    }            	
?>