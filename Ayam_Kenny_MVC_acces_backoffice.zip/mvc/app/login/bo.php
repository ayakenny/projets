<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Back Office</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body class='inverted'>

<?php
	require_once "login.php";
?>

<header>
	<h1>Back Office du site : My site</h1>
</header>
<section>
	<h2>
		Edition d'un article
	</h2>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
		<fieldset>
			<legend>Article</legend>
			<label for='titre'>Titre de l'article</label>
			<input tabindex="1" type="text" name="titre" id='titre' autofocus value="Article journal" />
			<label for='contenu'>Contenu</label>
			<textarea tabindex="2" id='contenu' name='contenu'>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</textarea>
			<input tabindex="3" type="submit" name="modifier" value='Mettre à jour'/>
		</fieldset>		
	</form>
</section>
<footer class="inverted">
	<a href="views/Layout/default.php">Retour</a> 
</footer>
</body>
</html>