<p>Bienvenue <?=$_SESSION['session_co']?></p><br/>

<form method='post' action='/backoffice'>
    <input type='submit' name='deco' value='Se déconnecter'/>
</form>
    
<footer class="inverted">
	<a href="/">Retour</a> 
</footer>