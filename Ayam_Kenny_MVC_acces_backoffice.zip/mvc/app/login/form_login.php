<form method='post' action='/backoffice'>
    <label for="login">Login :</label>
    <input type="text" id="login" name="login"/>

    <label for="mdp">Mot de passe :</label>
    <input type="password" id="mdp" name="mdp" minlength="5" required="required"/>

    <input type='submit' name='co' value='Se connecter'/>
</form>
    
<footer class="inverted">
	<a href="/">Retour</a> 
</footer>