<?php
    function erreur(mysqli $connexion){
        if($connexion->errno){
            echo "Erreur n°{$connexion->errno}:{$connexion->error}<br/>";
            exit(1);
        }
    }
?>