<?php
	class Article extends Model{

		public function __construct(){
			//nous définissons la table par défaut de ce modèle
			$this->table = "articles";
			
			//nous ouvrons la connexion à la BDD
			$this->getConnection();
		}

		public function findBySlug(string $slug){
			$sql = "SELECT * FROM ".$this->table." WHERE `slug`='".$slug."'";
			$query = $this->_connexion->query($sql);
			return $query->fetch_assoc();
		}
	}
?>