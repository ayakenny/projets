<h2>What a beautiful main</h2>

<a href="/articles">Nos articles du jour</a>
<br/>
<a href="/images">Nos images</a>
<br/>
<a href="/backoffice">Se connecter au backofice</a>