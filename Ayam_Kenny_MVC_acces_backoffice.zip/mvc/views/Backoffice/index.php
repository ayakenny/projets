<fieldset>
    <?php foreach($backoffice as $image):?>

    <form method="post" action="/backoffice/update/<?=$image['idimage']?>">
        <input type="text" name="lien" id="source" value="<?=$image['source']?>"/>
        <input type="text" name="lien" id="alt" value="<?=$image['alt']?>"/>
        <input type="submit" value="Mettre à jour"/>
    </form>
    <br/>

    <form method="post" action="/backoffice/delete/<?=$image['idimage']?>">
        <input type="submit" value="Effacer"/>
    </form>
    <br/>

    <?php endforeach?>
</fieldset>

<fieldset>
    <form method="post" action="/backoffice/insert/<?=$image['idimage']?>">
        <input type="text" name="lien" id="source" value="/backoffice/delete/"/>
        <input type="text" name="lien" id="alt" value="/backoffice/insert/"/>

        <input type="submit" value="Insérer"/>
    </form>
    <br/>
</fieldset>