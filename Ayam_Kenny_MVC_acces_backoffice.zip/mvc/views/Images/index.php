<div class="single_classe">
    <?php foreach($images as $image):?>
        <div class="image">
            <img classe="images" src="<?= $image['source'] ?>" alt="<?= $image['alt'] ?>" title="<?= $image['title'] ?>"/>
        </div>
    <?php endforeach?>
</div>

<div class="ma_classe">
    <?php foreach($images as $image):?>
        <div class="image">
            <img classe="images" src="<?= $image['source'] ?>" alt="<?= $image['alt'] ?>" title="<?= $image['title'] ?>"/>
        </div>
    <?php endforeach?>
</div>