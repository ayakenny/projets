<?php foreach($articles as $article):?>
	<div class="articles col-4 col-s-9"> 
		<h2><a href="/articles/lire/<?= $article['slug'] ?>"><?= $article['titre'] ?></a></h2>

		<div class="article">
			<!--<p><?= $article['contenu'] ?></p>Affiche le contenu de l'article-->
			<p><?= substr($article['contenu'],0,100) ?></p>
		</div>
	</div>
<?php endforeach?>

<!--Il faudrait répartir sur les 3 lignes les classes row mais il faut prendre en compte le foreach-->