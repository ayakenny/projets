<h2><?= $article['titre'] ?></h2>

<p><?= $article['contenu'] ?></p>

<a href="/articles">Retour à la liste des articles</a>