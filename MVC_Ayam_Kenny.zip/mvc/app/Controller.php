<?php
abstract class Controller{
	/**
	* Afficher une vue
	*
	* @param string $model
	* @param array $data
	* @return void
	*/

	public function loadModel(string $model){
		//on va chercher le fichier correspondant au modèle souhaité
		require_once(ROOT.'models/'.$model.'.php');

		//on créer une instance de ce modèle. Ainsi "Article" sera accessible par $this->Article
		$this->$model = new $model();
	}

	public function render(string $fichier, array $data = []){
		//récupère les données et les extraits sous forme de variables 
		extract($data);

		//On démarre le buffer de sortie
		ob_start();

		//crée le chemin et inclut le fichier de vue
		require_once(ROOT.'views/'.strtolower(get_class($this)).'/'.$fichier.'.php');

		//On stocke le contenu dans $content
		$content = ob_get_clean();

		//On fabrique le "template"
		require_once(ROOT.'views/layout/default.php');
	}
}
?>