$(document).ready(function(){
    $(".ma_classe").slick({
        infinite:true,
        slidesToShow:5,
        slidesToScroll:1,
        asNavFor:'.single_classe',
        autoplay:true,
        autoplaySpeed:2000,
        responsive: [
            {
              breakpoint: 1024,
              settings:{
                slidesToShow:5,
                slidesToScroll:1,
                asNavFor:'.single_classe',
              }
            },
            {
              breakpoint: 800,
              settings:{
                slidesToShow:3,
                slidesToScroll:1,
                asNavFor:'.single_classe',
              }
            },
            {
              breakpoint: 600,
              settings:{
                slidesToShow:2,
                slidesToScroll:1,
                asNavFor:'.single_classe',
              }
            }
          ]
    });

    $(".single_classe").slick({
        infinite:true,
        slidesToShow:1,
        slidesToScroll:1,
        dots:true,
        asNavFor:'.ma_classe', //Permet de syncrhoniser les deux caroussels. 
        autoplay:true,
        autoplaySpeed:2000,
    });
});

