<?php
class Images extends Controller{

	/**
	* Cette méthode affiche les images
	*
	* @return void
	*/

	public function index(){
		echo "Ici nous aurons les images";

		//on instancie le modèle "Image"
		$this->loadModel('Image');

		//on stocke la liste des images dans $images
		$images = $this->Image->getAll();

		//on affiche les données
		//var_dump($images);
		$this->render('index',compact('images'));
	}
}
?>