<?php
class Backoffice extends Controller{

	/**
	* Cette méthode récupère la liste d'images
	*
	* @return void
	*/

	public function index(){

		//On instancie le modèle "Image"
		$this->loadModel('Image');

		//On stocke la liste des images dans $backoffice
		$backoffice = $this->Image->getAll();

		//On affiche les données
		//var_dump($images);
		$this->render('index',compact('backoffice'));
	}

	public function delete(){
		//DELETE FROM `image` WHERE `image`.`idimage` = 10 - Requête pour supprimer une image
		//On doit l'intégrer avec une query 
	}
}
?>