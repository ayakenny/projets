<!DOCTYPE html>
<html lang="fr">
<meta charset="utf-8">
<head>
	<title>Mon super MVC</title>

	<link rel="stylesheet" type="text/css" href="../slick/slick.css"/>
	<link rel="stylesheet" type="text/css" href="../slick/slick-theme.css"/>
	<link rel="stylesheet" href="../css/style.css"/>
	<link rel="stylesheet" href="../css/image.css"/>
	<link rel="stylesheet" href="../css/responsive.css"/>
</head>
<body>
	<header>
		<h1>Welcome here</h1>
	</header>

	<main>
		<?= $content ?>
	</main>

	<footer>
		<p>Copyright 2021</p>
	</footer>

	<script type="text/javascript" src="../js/jquery-3.2.0.min.js"></script>

	<script src="../slick/slick.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" src="../js/fonction.js"></script>

</body>
</html>