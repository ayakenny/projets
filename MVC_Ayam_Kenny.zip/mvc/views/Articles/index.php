<?php foreach($articles as $article):?>

	<h2><a href="/articles/lire/<?= $article['slug'] ?>"><?= $article['titre'] ?></a></h2>

	<div class="article">
		<!--<p><?= $article['contenu'] ?></p> Affiche le contenu de l'article-->
		<p><?= substr($article['contenu'],0,100) ?></p>
	</div>

<?php endforeach?>