<?php
//require_once "gestion_erreur_globale.php";
define('ROOT', str_replace('index.php','',$_SERVER['SCRIPT_FILENAME'])); //Chemin vers la racine du projet

//Appelle du modèle et contrôleur
require_once(ROOT.'app/Model.php'); 
require_once(ROOT.'app/Controller.php');

//Pour séparer les paramètres
$params = explode('/', $_GET['p']);

//var_dump(ROOT);
if(empty($params[1]))
    unset($params[1]);

//var_dump($params); //Je l'ai mis en commentaire pour éviter d'afficher dans le navigateur les informations de $params
if($params[0] != ""){ //Si au moins 1 paramètre existe
    $controller = ucfirst($params[0]); //On sauvegarde le 1er param ds $controller en mettant sa 1ère lettre en maj
    $action = isset($params[1]) ? $params[1] : 'index'; //On sauvegarde le 2e param dans $action s'il existe, snn index
    require_once(ROOT.'controllers/'.$controller.'.php'); //On appelle le controller
    $controller = new $controller(); //On instancie le contrôleur
    //var_dump($controller);
    //var_dump($action);
    if(method_exists($controller, $action)){
        unset($params[0]); unset($params[1]);
        //Appelle la méthode $action du contrôleur $controller
        call_user_func_array([$controller,$action], $params);
    }else{
        http_response_code(404); //Envoie le code réponse "Erreur 404"
        echo "La page recherchée n'existe pas";
    }
}else{
    //Ici aucun paramètre n'est défini
    //On appelle le contrôleur par défaut
    require_once(ROOT.'controllers/Main.php');
    $controller = new Main(); //instancie le contrôleur
    $controller->index(); //appelle la méthode index
}
?>